# Angular-4-Assignment-1 from Angular - The Complete Guide

https://www.udemy.com/the-complete-guide-to-angular-2/

First assignment to practice skills learned so far.

Task objectives:
1. Create two new components (manually or with CLI): WarningAlert and SuccessAlert
2. Output them beneath each other in the AppComponent
3. Output a warning or success message in the components
4. Stype the components appropriately (maybe some red/green text?)

Use external or internal templates and styles!

Feel fee to create more components, nest them into each other or play around with different types of selectors!

![Alt text](images/Angular-4-Assignment-1-ScreenShot.png?raw=true "Screen Shot")

